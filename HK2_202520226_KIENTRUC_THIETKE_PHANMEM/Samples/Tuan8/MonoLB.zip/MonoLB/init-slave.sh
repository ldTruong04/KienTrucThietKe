#!/bin/bash
set -e

echo "Waiting MariaDB Slave nội bộ khởi động..."
until mariadb-admin ping -h localhost -p${MARIADB_ROOT_PASSWORD} --silent; do
    sleep 2
done

echo "Waiting Master (mariadb-master) sẵn sàng..."
until mariadb -h"mariadb-master" -u"root" -p${MARIADB_ROOT_PASSWORD} -e "SELECT 1" > /dev/null 2>&1; do
    sleep 3
done

echo "Thiết lập Replication..."

mariadb -u root -p${MARIADB_ROOT_PASSWORD} <<EOSQL
STOP SLAVE;
RESET SLAVE ALL;

-- Thiết lập kết nối
CHANGE MASTER TO
    MASTER_HOST='mariadb-master',
    MASTER_USER='root',
    MASTER_PASSWORD='${MARIADB_ROOT_PASSWORD}',
    MASTER_PORT=3306,
    MASTER_CONNECT_RETRY=10,
    MASTER_USE_GTID=current_pos;

START SLAVE;
EOSQL

echo "Thiết lập Slave hoàn tất!"
