import axios from 'axios';

const baseURL = import.meta.env.VITE_API_URL || '/api';

console.log(baseURL);

const api = axios.create({
    baseURL: baseURL
});

api.interceptors.response.use(
    (response) => {
        return response;
    },
    (error) => {
        if (error.response && error.response.status === 429) {
            console.error("Rate limit exceeded!");
            alert("Thao tác quá nhanh! Vui lòng đợi vài giây rồi thử lại.");
        }

        return Promise.reject(error);
    }
);

export const getProducts = () => api.get('/products');
export const createProduct = (data) => api.post('/products', data);
