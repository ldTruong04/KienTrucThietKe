import React from 'react'
import { useEffect, useState } from 'react'
import { getProducts } from '../services/api'

export default function ProductList() {
    const [products, setProducts] = useState([])

    useEffect(() => {
        getProducts().then(res => setProducts(res.data))
    }, [])

    return (
        <div>
            <h1>Danh sách sản phẩm (Lấy từ Slave)</h1>
            <table border="1" width="100%">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Tên</th>
                    <th>Giá</th>
                </tr>
                </thead>
                <tbody>
                {products.map(p => (
                    <tr key={p.id}>
                        <td>{p.id}</td>
                        <td>{p.name}</td>
                        <td>{p.price}</td>
                    </tr>
                ))}
                </tbody>
            </table>
        </div>
    )
}
