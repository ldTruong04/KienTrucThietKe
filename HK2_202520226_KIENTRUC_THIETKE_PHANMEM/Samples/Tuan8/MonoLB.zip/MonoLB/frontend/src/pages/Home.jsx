import React from 'react'
import { useState } from 'react'
import { createProduct } from '../services/api'

export default function Home() {
    const [name, setName] = useState('')

    const handleAdd = async () => {
        console.log("Đang gọi API...");
        try {
            const response = await createProduct({ name, price: 100 });
            console.log("Kết quả:", response.data);
        } catch (err) {
            console.error("Lỗi gọi API:", err);
        }
    };

    return (
        <div>
            <h1>Dùng Master DB</h1>
            <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Nhập tên sản phẩm"
            />
            <button onClick={handleAdd}>Thêm</button>
        </div>
    )
}
