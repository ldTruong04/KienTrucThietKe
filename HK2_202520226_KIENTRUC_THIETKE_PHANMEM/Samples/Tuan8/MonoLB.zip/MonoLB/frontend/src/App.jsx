import React, { useEffect, useState } from 'react';
import { Routes, Route, Link } from 'react-router-dom'
import Home from './pages/Home'
import ProductList from './pages/ProductList'

function App() {
    const [serverID, setServerID] = useState("Đang kiểm tra...");

    useEffect(() => {
        // Gọi tới chính root để lấy Header của trang hiện tại
        fetch('/')
            .then(response => {
                const id = response.headers.get('x-server-id');
                setServerID(id || "Không tìm thấy ID");
            })
            .catch(err => setServerID("Lỗi kết nối"));
    }, []);
    return (
        <div>
            <div style={{ color: 'green', fontWeight: 'bold' }}>
                Đang chạy trên Container: {serverID}
            </div>
            <nav style={{ padding: '20px', background: '#eee' }}>
                <Link to="/" style={{ marginRight: '10px' }}>Trang chủ</Link>
                <Link to="/products">Danh sách sản phẩm</Link>
            </nav>

            <div style={{ padding: '20px' }}>
                <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/products" element={<ProductList />} />
                </Routes>
            </div>
        </div>
    )
}
export default App