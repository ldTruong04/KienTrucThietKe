import os from 'os'
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
    plugins: [
        react({
            jsxRuntime: 'automatic',
        })
    ],
    resolve: {
        dedupe: ['react', 'react-dom', 'react-router-dom'],
    },
    server: {
        host: true, // Cho phép truy cập từ bên ngoài container (cần thiết cho Docker)
        port: 5173,
        // Cấu hình để Hot Reload hoạt động tốt trên các hệ điều hành khác nhau qua Docker Volume
        watch: {
            usePolling: true,
        },
        // Chặn lỗi WebSocket khi chạy qua Nginx Reverse Proxy
        hmr: {
            clientPort: 80, // Nginx đang chạy ở cổng 80
        },
        headers: {
            'X-Server-ID': os.hostname(),
        },
    },
})
