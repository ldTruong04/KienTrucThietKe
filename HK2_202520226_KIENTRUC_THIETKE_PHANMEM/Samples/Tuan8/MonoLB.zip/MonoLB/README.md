1. File thiết lập đồng bộ data từ DB Master sang DB Slave
   init-slave.sh
2. Run docker - chạy lệnh bên dưới để build, pull và xem log
   docker compose up
3. Truy cập vào container Master để xem status của MASTER
   docker exec -it mariadb-master mariadb -u root -p root
   SHOW MASTER STATUS;
4. Truy cập vào container Slave để xem status của SLAVE
   SHOW SLAVE STATUS\G;

   Kiểm tra 2 dòng quan trọng để xem đã setting đồng bộ từ MASTER sàn SLAVE được hay chưa?
   Slave_IO_Running: Yes
   Slave_SQL_Running: Yes
5. URL web:
   http://localhost
   => Thêm product => lưu vào Master DB => sau đó sẽ đồng bộ tự động qua Slave DB (vào container check lại)
   http://localhost/products
   => Lấy danh sách product => lấy từ Slave DB
6. Lệnh chạy để scale service:
   Lệnh chạy để có 3 Backend và 2 Frontend
   docker compose up -d --build --scale backend=3 --scale frontend=2
