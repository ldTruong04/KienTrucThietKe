package iuh.fit.se.backend.controllers;

import iuh.fit.se.backend.entities.Product;
import iuh.fit.se.backend.services.ProductService;
import org.springframework.web.bind.annotation.*;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;

@RestController
@RequestMapping("/api/products")
@CrossOrigin(origins = "*")
public class ProductController {

    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping
    public List<Product> list() throws UnknownHostException {
        System.out.println("Request handled by: " + InetAddress.getLocalHost().getHostAddress());
        return productService.getAll();
    }

    @PostMapping
    public Product create(@RequestBody Product product) {
        return productService.save(product);
    }
}
