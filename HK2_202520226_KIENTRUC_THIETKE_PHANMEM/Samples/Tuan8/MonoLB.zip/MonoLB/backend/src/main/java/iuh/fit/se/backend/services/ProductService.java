package iuh.fit.se.backend.services;


import iuh.fit.se.backend.entities.Product;

import java.util.List;

public interface ProductService {
    public Product save(Product product);
    public List<Product> getAll();
    public Product getById(Long id);
}
