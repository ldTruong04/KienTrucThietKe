package iuh.fit.se.backend.services.impl;


import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import iuh.fit.se.backend.config.DataSourceContext;
import iuh.fit.se.backend.entities.Product;
import iuh.fit.se.backend.repositories.ProductRepository;
import iuh.fit.se.backend.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ProductServiceImpl implements ProductService {

    private final ProductRepository productRepository;

    @Autowired
    public ProductServiceImpl(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    @Override
    @Transactional
    public Product save(Product product) {
        return productRepository.save(product);
    }

    @Override
    // Thử lại 3 lần, mỗi lần cách nhau 2s. Nếu vẫn hỏng thì gọi fallback
    @Retry(name = "slaveDatabase")
    @CircuitBreaker(name = "slaveDatabase", fallbackMethod = "fallbackToMaster")
    @Transactional(readOnly = true)
    public List<Product> getAll() {
        return productRepository.findAll();
    }

    private List<Product> fallbackToMaster(Exception e) {
        System.out.println("Slave đang lỗi, đang chuyển hướng đọc từ Master...");
        // Ép buộc dùng Master bằng cách xóa context SLAVE
        DataSourceContext.set(DataSourceContext.DataSourceType.MASTER);
        return productRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Product getById(Long id) {
        return productRepository.findById(id).orElseThrow(()-> new RuntimeException("product not found"));
    }
}
