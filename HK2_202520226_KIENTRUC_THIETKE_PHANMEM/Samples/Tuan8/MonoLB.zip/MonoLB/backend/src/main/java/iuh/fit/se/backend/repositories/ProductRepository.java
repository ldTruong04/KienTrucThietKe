package iuh.fit.se.backend.repositories;


import iuh.fit.se.backend.entities.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, Long> {
}
