package iuh.fit.se.backend.aspect;

import iuh.fit.se.backend.config.DataSourceContext;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Aspect
@Component
@Order(0)
public class DataSourceAspect {

    @Before("@annotation(transactional)")
    public void setDataSource(Transactional transactional) {
        if (transactional.readOnly()) {
            DataSourceContext.set(DataSourceContext.DataSourceType.SLAVE);
        } else {
            DataSourceContext.set(DataSourceContext.DataSourceType.MASTER);
        }
    }

    @After("@annotation(transactional)")
    public void clearDataSource(Transactional transactional) {
        DataSourceContext.clear();
    }
}
