package iuh.fit.se.backend.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import javax.sql.DataSource;
import java.util.Map;

@Configuration
public class DataSourceConfig {

    @Bean
    @ConfigurationProperties("spring.datasource.master")
    public DataSource masterDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean
    @ConfigurationProperties("spring.datasource.slave")
    public DataSource slaveDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean
    @Primary
    public DataSource dataSource() {
        var routing = new RoutingDataSource();

        routing.setTargetDataSources(Map.of(
                DataSourceContext.DataSourceType.MASTER, masterDataSource(),
                DataSourceContext.DataSourceType.SLAVE, slaveDataSource()
        ));

        routing.setDefaultTargetDataSource(masterDataSource());
        return routing;
    }
}
